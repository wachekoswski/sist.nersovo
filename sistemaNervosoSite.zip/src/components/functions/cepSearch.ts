import Axios from 'axios';

import { UseFormSetValue } from 'react-hook-form';

// import { FormValues } from '../../pages/inscricao/inscricao';

const cepSearch = async (cep:string, setValueF:any) => {
    //NO LUGAR DO ANY PUXAR UMA INTERFACE SETVALUE
    return Axios.get(`https://brasilapi.com.br/api/cep/v2/${cep}`)
    .then(
        ({data}) => 
        {
            setValueF('logradouro', data.street);
            setValueF('cidade', data.city);
            setValueF('bairro', data.neighborhood);
            setValueF('uf', data.state);
            return true;
        }
    )
    .catch(
        (e) => 
        {
            console.log(e.response)
            return false;
        }
    )
}

export { cepSearch }