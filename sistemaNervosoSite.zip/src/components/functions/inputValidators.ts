const cpfValidator = (cpfInput: string) => {
   let cpf = cpfInput.replace(/[^\d]+/g,'');
   if(cpf == '')
   {
      return false;
   }
   // Elimina CPFs invalidos conhecidos	
   if (cpf.length != 11 || 
      cpf == "00000000000" || 
      cpf == "11111111111" || 
      cpf == "22222222222" || 
      cpf == "33333333333" || 
      cpf == "44444444444" || 
      cpf == "55555555555" || 
      cpf == "66666666666" || 
      cpf == "77777777777" || 
      cpf == "88888888888" || 
      cpf == "99999999999")
      {
         return false;
      }
   // Valida 1o digito	
   let add = 0;	
   for (let i=0; i < 9; i++)
      add += parseInt(cpf.charAt(i)) * (10 - i);	

      let rev = 11 - (add % 11);
      if (rev == 10 || rev == 11)		
         rev = 0;	

      if (rev != parseInt(cpf.charAt(9)))
      {
         return false;
      }

   // Valida 2o digito	
   add = 0;	
   for (let i = 0; i < 10; i ++)		
      add += parseInt(cpf.charAt(i)) * (11 - i);	
   rev = 11 - (add % 11);	
   if (rev == 10 || rev == 11)	
      rev = 0;	
   if (rev != parseInt(cpf.charAt(10)))
   {
      return false;
   }	
   return true;
}

const rgValidator = (value:string) => {
   return value.replace(/[^\d]/g, "").substring(0,255);
}

const dataValidator = (value:string, type?: "date" | "datetime") => {
   if(!value || value.length < 1)
      return true;
   let dateValue = value;
   if(value.replace(/_/g, "").length < 10)
      return false;
   if(type && type === "datetime")
      dateValue = value.split(" ")[0];
   let arrData = dateValue.replace(/[^\d\/]/g, "").split("/");
   if(parseInt(arrData[1]) > 12)
      return false;
   switch(arrData[1])
   {
      case '01':
      case '03':
      case '05':
      case '07':
      case '08':
      case '10':
      case '12':
      {
         if(parseInt(arrData[0]) > 31)
            return false
         break;
      }
      case '02': 
      {
         if(parseInt(arrData[0]) > 29)
            return false
         break;
      }
      default:
      {
         if(parseInt(arrData[0]) > 30)
            return false
         break;
      }
   }
   if(type && type === "datetime")
   {
      const timeValue = value.split(" ")[1].split(":");
      if(parseInt(timeValue[0]) > 23 || parseInt(timeValue[1]) > 59)
         return false
   }
   return true;
}

const pisValidator = (pis:string) => {
   var multiplicadorBase = "3298765432";
   var total = 0;
   var resto = 0;
   var multiplicando = 0;
   var multiplicador = 0;
   var digito = 99;
   
   // Retira a mascara
   var numeroPIS = pis.replace(/[^\d]+/g, '');

   if (numeroPIS.length !== 11 || 
       numeroPIS === "00000000000" || 
       numeroPIS === "11111111111" || 
       numeroPIS === "22222222222" || 
       numeroPIS === "33333333333" || 
       numeroPIS === "44444444444" || 
       numeroPIS === "55555555555" || 
       numeroPIS === "66666666666" || 
       numeroPIS === "77777777777" || 
       numeroPIS === "88888888888" || 
       numeroPIS === "99999999999") {
       return false;
   } else {
       for (var i = 0; i < 10; i++) {
           multiplicando = parseInt( numeroPIS.substring( i, i + 1 ) );
           multiplicador = parseInt( multiplicadorBase.substring( i, i + 1 ) );
           total += multiplicando * multiplicador;
       }

       resto = 11 - total % 11;
       resto = resto === 10 || resto === 11 ? 0 : resto;

       digito = parseInt("" + numeroPIS.charAt(10));
       return resto === digito;
   }
}

const dataBrToNumber = (value: string) =>
{
   let arrData = value.split("/");
   return arrData[2]+arrData[1]+arrData[0];
}

const decimalBrToUs = (value: string) =>
{
   let decimal = value.replace(/\./g, "").replace(/,/g, ".");
   return parseFloat(decimal);
}

const decimalUsToBr = (value: string) =>
{
   let decimal = value.replace(/\./g, ",");
   return decimal.match(/\,/g) ? decimal : decimal+',00';
}

const maskValueBr = (value: string) =>
{
   let arr = value.split(",");
   let count = 0;
   let numberBumper = "";
   for(let i = arr[0].length - 1; i >= 0; i--)
   {
      numberBumper = arr[0][i] + numberBumper;
      count++;
      if(count === 3)
      {
         count = 0;
         numberBumper = "." + numberBumper;
      }
   }
   return numberBumper+","+arr[1];
} 

const birthDateToYears = (value: string) => {
   console.log(parseInt(new Date().getFullYear().toString()+(new Date().getMonth().toString().length < 2 ? '0'+new Date().getMonth().toString() : new Date().getMonth().toString())+new Date().getDate().toString()))
   if(value && dataValidator(value, "date"))
      return Math.floor(((parseInt(new Date().getFullYear().toString()+(new Date().getMonth().toString().length < 2 ? '0'+new Date().getMonth().toString() : new Date().getMonth().toString())+(new Date().getDate().toString().length < 2 ? '0'+new Date().getDate().toString() : new Date().getDate().toString())) - parseInt(dataBrToNumber(value)))/10000) + 0.01)
}

export { cpfValidator, rgValidator, dataValidator, pisValidator, decimalBrToUs, decimalUsToBr, dataBrToNumber, maskValueBr, birthDateToYears}