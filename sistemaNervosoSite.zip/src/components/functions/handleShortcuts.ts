type ArrayShotscuts = {
   key: string;
   ctrl?: boolean;
   alt?: boolean;
   action: () => boolean;
}[]

const callShortcuts = (e: any, arrayShortCuts: ArrayShotscuts ) => {
   arrayShortCuts.some(
      (test) => {
         if(e.key === test.key && !test.ctrl && !test.alt)
            return test.action()
         if(test.ctrl)
            if(e.key === test.key && e.ctrlKey)
               return test.action()
         if(test.alt)
            if(e.key === test.key && e.altKey)
               return test.action()
      }
   )
   // if(e.key === "Enter")
   // {
   //    if(e.target && e.target.form)
   //    {
   //       const form = e.target.form;
   //       let index = [...form].indexOf(e.target);

   //       if(form[index].tagName === "BUTTON")
   //       {
   //          form[index].submit();
   //       }

   //       if(form[index + 1])
   //       {
   //          while(form[index + 1].tabIndex === -1 || form[index + 1].disabled || form[index + 1].class === "pageTabs__tab")
   //          {
   //             index++;
   //          }
   //          if(form[index + 1].tagName === "BUTTON" && form[index].tagName !== "BUTTON" && form[index + 1].tabIndex !== -1 && !form[index + 1].disabled)
   //             e.preventDefault();
   //          setTimeout(() => form[index + 1].focus(), 5)
   //       }
   //    }
   // }
};

// const callShortcuts = (e: any) =>
// {
//    if(e.key === "Enter")
//    {
//       if(e.target)
//       {
//          const form = e.target.form;
//          let index = [...form].indexOf(e.target);
//          while(form[index + 1].class === "pageTabs__tab")
//          {
//             index++;
//          }
//          if(form[index + 1].tabIndex !== -1 && !form[index + 1].disabled)
//          {
//             form[index + 1].focus();
//          }
//          else{
//             form[index + 2].focus();
//          }
//       }
//    }
// }

 export { callShortcuts }