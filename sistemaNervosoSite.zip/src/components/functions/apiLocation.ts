const api = () => {
   // return "http://192.168.50.31/sisCentroFormacao";
   // return "http://192.168.1.100/sisCentroFormacao";
   // return "http://192.168.2.20/sisCentroFormacao";
   return "http://localhost/sisCentroFormacao";
}

export { api }